fx_version 'cerulean'
game 'gta5'

name "NoPixel Inspired Dongle Ped"
author "Made with love by Samuel, Blindboom, Soda"
version "2.0"

client_scripts {
	'client.lua',
	'config.lua'
}

server_scripts {
	'server.lua',
	'config.lua'
}
