Just a Edit of Samuel sd-dongle to work with Renewed Crypto Phone


- Origial Creator: https://github.com/Github-Samuel

- Renewd Phone: https://github.com/Renewed-Scripts/qb-phone


- You can add more items and the type crypto you wanna use in the config 

--
Config.Shop = {
    [1] = {
        item = "deliverylist",-- Item
        price = 100,-- Price of item
        type = "shung", -- Crypto Type /gne/shung/xcoin/lme (or what ever you named tour crypto lol)
        icon = "fa-solid fa-clipboard", -- Icons from https://fontawesome.com/
    },
}
--

Should be a basic drag and drop file